"use strict";

const browserApi = globalThis.browser?.runtime ? globalThis.browser : globalThis.chrome;
const { request: requestDataConsent } = globalThis.SuchfilterDataConsent;
let currentDomain = null;
let cooldownActive = false;
const DOMAIN_PATTERN =
  /^(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?$/;

function message(payload) {
  return new Promise((resolve, reject) => {
    browserApi.runtime.sendMessage(payload, (response) => {
      if (browserApi.runtime.lastError) reject(browserApi.runtime.lastError);
      else if (!response?.ok) reject(new Error(response?.error || "Erweiterungsanfrage fehlgeschlagen"));
      else resolve(response.value);
    });
  });
}

function renderStatus(status) {
  const dot = document.querySelector("#status-dot");
  dot.className = `status-dot ${status.online ? "online" : "offline"}`;
  cooldownActive = Boolean(status.cooldown);
  document.querySelector(".logo").className = `logo ${
    cooldownActive ? "cooldown" : status.online ? "online" : "offline"
  }`;
  document.querySelector("#status-title").textContent = status.online
    ? "Filterdienst ist bereit"
    : "Filterdienst nicht erreichbar";
  const detail = document.querySelector("#status-detail");
  detail.hidden = status.online;
  detail.textContent = status.online ? "" : "Internetverbindung prüfen und erneut versuchen.";
  const cooldownCard = document.querySelector("#cooldown-card");
  cooldownCard.hidden = !cooldownActive;
  document.querySelector("#cooldown-detail").textContent = cooldownActive
    ? `Noch ${status.cooldown.label}. Danach sind Meldungen wieder möglich.`
    : "";
  enableReportButtons(currentDomain !== null);
}

function activeTab() {
  return new Promise((resolve, reject) => {
    browserApi.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (browserApi.runtime.lastError) reject(browserApi.runtime.lastError);
      else resolve(tabs[0] || null);
    });
  });
}

function domainFromTab(tab) {
  if (typeof tab?.url !== "string") return null;
  try {
    const url = new URL(tab.url);
    if (!["http:", "https:"].includes(url.protocol) || !url.hostname) return null;
    const hostname = url.hostname.toLowerCase().replace(/\.$/, "");
    if (
      !DOMAIN_PATTERN.test(hostname) ||
      /^(?:[0-9]{1,3}\.){3}[0-9]{1,3}$/.test(hostname) ||
      isSearchEngineDomain(hostname)
    )
      return null;
    return hostname;
  } catch {
    return null;
  }
}

function isSearchEngineDomain(hostname) {
  if (
    hostname === "news.google.com" ||
    hostname === "search.brave.com" ||
    hostname === "bing.com" ||
    hostname.endsWith(".bing.com") ||
    hostname === "duckduckgo.com" ||
    hostname.endsWith(".duckduckgo.com")
  )
    return true;
  return /^(?:www\.)?google\.[a-z0-9-]+(?:\.[a-z0-9-]+)*$/.test(hostname);
}

function enableReportButtons(enabled) {
  for (const button of document.querySelectorAll(".report-option")) {
    button.disabled = !enabled || cooldownActive;
  }
}

function renderCurrentDomain(domain) {
  const current = document.querySelector("#current-domain");
  const unavailable = document.querySelector("#report-unavailable");
  currentDomain = domain;
  current.hidden = domain === null;
  unavailable.hidden = domain !== null;
  if (domain !== null) current.textContent = domain;
  enableReportButtons(domain !== null);
}

async function loadCurrentDomain() {
  const domain = domainFromTab(await activeTab());
  renderCurrentDomain(domain);
}

async function submitReport(category) {
  if (currentDomain === null || !["hard", "light"].includes(category)) return;
  const feedback = document.querySelector("#report-feedback");
  enableReportButtons(false);
  feedback.className = "pending";
  feedback.textContent = "Meldung wird gesendet …";
  try {
    const granted = await requestDataConsent(["browsingActivity", "personallyIdentifyingInfo"]);
    if (!granted) {
      feedback.className = "error";
      feedback.textContent = "Meldung nicht gesendet: Datenschutz-Zustimmung wurde nicht erteilt.";
      return;
    }
    const receipt = await message({ type: "report", domain: currentDomain, category });
    feedback.className = "success";
    feedback.textContent = receipt.duplicate ? "Bereits gemeldet." : "Zur Prüfung eingereicht.";
  } catch (error) {
    feedback.className = "error";
    if (error.message.startsWith("Ungewöhnliche Meldefrequenz")) {
      feedback.textContent = error.message;
      await updateStatus();
    } else {
      feedback.textContent = "Meldung fehlgeschlagen. Bitte Verbindung prüfen.";
    }
  } finally {
    enableReportButtons(currentDomain !== null);
  }
}

async function updateStatus() {
  const retry = document.querySelector("#retry");
  retry.disabled = true;
  try {
    renderStatus(await message({ type: "status" }));
  } catch {
    renderStatus({ online: false });
  } finally {
    retry.disabled = false;
  }
}

for (const button of document.querySelectorAll(".report-option")) {
  button.addEventListener("click", () => submitReport(button.dataset.category));
}
document.querySelector("#retry").addEventListener("click", updateStatus);
document.querySelector("#open-settings").addEventListener("click", (event) => {
  event.preventDefault();
  browserApi.runtime.openOptionsPage();
});
loadCurrentDomain().catch(() => {
  renderCurrentDomain(null);
});
updateStatus();
